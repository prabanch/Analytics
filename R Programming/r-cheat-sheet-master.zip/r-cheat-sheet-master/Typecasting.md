# Typecasting

```
> x <- "4"
> typeof(x)
[1] "character"
```

## as.numeric

```
> typeof(as.numeric(x))
[1] "double"
```

## as.integer

```
> typeof(as.integer(x))
[1] integer
```
