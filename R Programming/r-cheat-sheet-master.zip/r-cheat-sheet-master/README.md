# README
These are the notes I take for myself while working in R.

If you spot any mistakes or have any suggestions, feel free to submit a pull request or drop me an email at matthew.h.mazur@gmail.com. Thanks!